import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductsComponent } from './components/products/products.component';
import { SelectedStudentsComponent } from './components/selected-students/selected-students.component';

const routes: Routes = [
  {
    path : '',
    component: ProductsComponent
  },
  {
    path : 'selected-students',
    component: SelectedStudentsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule { }
