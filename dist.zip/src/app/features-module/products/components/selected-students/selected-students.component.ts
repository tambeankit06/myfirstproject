import { Component, OnInit } from '@angular/core';
import { MainServiceService } from 'src/app/features-module/main-service.service';

@Component({
  selector: 'app-selected-students',
  templateUrl: './selected-students.component.html',
  styleUrls: ['./selected-students.component.css']
})
export class SelectedStudentsComponent implements OnInit {

  constructor(public mainService : MainServiceService) { }

  ngOnInit(): void {
  }

}
