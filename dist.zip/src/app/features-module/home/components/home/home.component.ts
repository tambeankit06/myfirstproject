import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  loginForm = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
  });

  constructor(private router: Router) { }

  ngOnInit(): void {
    
    
  }

  login = () => {
      if (this.loginForm.valid) {
        alert("Login Successfull");
        this.loginForm.reset();
        this.router.navigateByUrl('/products');
      } else {
        alert("Please fill required field as mentioned as *");
      }
  }

}
